﻿#pragma warning disable 1591

namespace Apex.AI.Examples
{
    using Apex.Serialization;
    using Memory;

    /// <summary>
    /// A specific utility curve scorer for scoring the entity's current ammunition count.
    /// </summary>
    public sealed class UtilityCurveAmmoScorer : UtilityCurveGeneralBaseScorer
    {
        [ApexSerialization, FriendlyName("Ammo Multiplier", "A factor used to multiply the entity's current ammunition count before getting the corresponding utility score.")]
        public float ammoMultiplier = 10f;

        public override float Score(IAIContext context)
        {
            var c = (AIContext)context;
            return this.GetUtilityScore(c.entity.currentAmmo * this.ammoMultiplier);
        }
    }
}
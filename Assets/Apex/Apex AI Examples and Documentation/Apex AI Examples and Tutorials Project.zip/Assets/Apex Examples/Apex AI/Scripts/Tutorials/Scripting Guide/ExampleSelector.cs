﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Tutorial
{
    using System.Collections.Generic;

    public sealed class ExampleSelector : Selector
    {
        public ExampleSelector()
            : base()
        {
        }

        public override IQualifier Select(IAIContext context, IList<IQualifier> qualifiers, IDefaultQualifier defaultQualifier)
        {
            /* Put logic here */

            return defaultQualifier;
        }
    }
}
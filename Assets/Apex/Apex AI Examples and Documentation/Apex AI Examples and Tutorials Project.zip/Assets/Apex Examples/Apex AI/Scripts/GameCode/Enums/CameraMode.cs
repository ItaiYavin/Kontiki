﻿#pragma warning disable 1591

namespace Apex.AI.Examples
{
    public enum CameraMode
    {
        Isometric,
        TopDown,
        Static
    }
}
﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Components
{
    using Memory;
    using UnityEngine;
    using Visualization;

    public class MoveTargetVisualizerDebugComponent : ContextGizmoVisualizerComponent
    {
        public Color gizmosColor = Color.yellow;
        public float sphereSize = 2f;

        protected override void DrawGizmos(IAIContext context)
        {
            var c = (AIContext)context;
            var moveTarget = c.entity.moveTarget;
            if (!moveTarget.HasValue)
            {
                return;
            }

            Gizmos.color = this.gizmosColor;
            Gizmos.DrawWireSphere(moveTarget.Value, this.sphereSize);
        }
    }
}
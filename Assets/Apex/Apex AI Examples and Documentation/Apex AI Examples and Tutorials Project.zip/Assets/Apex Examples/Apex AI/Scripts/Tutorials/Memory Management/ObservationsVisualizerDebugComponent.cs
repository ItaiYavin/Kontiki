﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Tutorial
{
    using UnityEngine;
    using Visualization;

    public sealed class ObservationsVisualizerDebugComponent : ContextGizmoVisualizerComponent
    {
        public Color gizmosColor = Color.yellow;

        protected override void DrawGizmos(IAIContext context)
        {
            var c = (ExampleContext)context;
            var pos = this.transform.position;
            var observations = c.observations;
            var count = observations.Count;

            Gizmos.color = this.gizmosColor;
            for (int i = 0; i < count; i++)
            {
                Gizmos.DrawLine(pos, observations[i].transform.position);
            }
        }
    }
}
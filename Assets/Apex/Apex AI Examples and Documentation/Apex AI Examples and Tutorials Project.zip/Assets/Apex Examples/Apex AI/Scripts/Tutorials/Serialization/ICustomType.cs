﻿#pragma warning disable 1591

namespace Apex.AI.Examples.Tutorial
{
    public interface ICustomType
    {
    }
}

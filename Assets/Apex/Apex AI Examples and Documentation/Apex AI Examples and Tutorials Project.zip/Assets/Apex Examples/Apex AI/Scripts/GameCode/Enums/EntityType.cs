#pragma warning disable 1591

namespace Apex.AI.Examples
{
    public enum EntityType
    {
        None = 0,
        Any = ~0,
        Player,
        Drone,
        Marine
    }
}